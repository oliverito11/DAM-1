/*******************************************************************************
 * 2020, All rights reserved.
 *******************************************************************************/

// Start of user code (user defined imports)

// End of user code

/**
 * Description of Persona.
 * 
 * @author mañana
 */
public class Persona {
	/**
	 * Description of the property Nombre.
	 */
	private String Nombre = "";

	/**
	 * Description of the property Correo.
	 */
	private String Correo = "";

	/**
	 * Description of the property Direccion.
	 */
	private String Direccion = "";

	// Start of user code (user defined attributes for Persona)

	// End of user code

	/**
	 * The constructor.
	 */
	public Persona() {
		// Start of user code constructor for Persona)
		super();
		// End of user code
	}

	/**
	 * Description of the method getNombre.
	 * @return 
	 */
	public String getNombre() {
		// Start of user code for method getNombre
		String getNombre = "";
		return getNombre;
		// End of user code
	}

	/**
	 * Description of the method getCorreo.
	 * @return 
	 */
	public String getCorreo() {
		// Start of user code for method getCorreo
		String getCorreo = "";
		return getCorreo;
		// End of user code
	}

	/**
	 * Description of the method getDireccion.
	 * @return 
	 */
	public String getDireccion() {
		// Start of user code for method getDireccion
		String getDireccion = "";
		return getDireccion;
		// End of user code
	}

	/**
	 * Description of the method setNombre.
	 * @param Nombre 
	 */
	public void setNombre(String Nombre) {
		// Start of user code for method setNombre
		// End of user code
	}

	/**
	 * Description of the method setCorreo.
	 * @param Correo 
	 */
	public void setCorreo(String Correo) {
		// Start of user code for method setCorreo
		// End of user code
	}

	/**
	 * Description of the method setDireccion.
	 * @param Direccion 
	 */
	public void setDireccion(String Direccion) {
		// Start of user code for method setDireccion
		// End of user code
	}

	// Start of user code (user defined methods for Persona)

	// End of user code
	/**
	 * Returns Nombre.
	 * @return Nombre 
	 */
	public String getNombre() {
		return this.Nombre;
	}

	/**
	 * Sets a value to attribute Nombre. 
	 * @param newNombre 
	 */
	public void setNombre(String newNombre) {
		this.Nombre = newNombre;
	}

	/**
	 * Returns Correo.
	 * @return Correo 
	 */
	public String getCorreo() {
		return this.Correo;
	}

	/**
	 * Sets a value to attribute Correo. 
	 * @param newCorreo 
	 */
	public void setCorreo(String newCorreo) {
		this.Correo = newCorreo;
	}

	/**
	 * Returns Direccion.
	 * @return Direccion 
	 */
	public String getDireccion() {
		return this.Direccion;
	}

	/**
	 * Sets a value to attribute Direccion. 
	 * @param newDireccion 
	 */
	public void setDireccion(String newDireccion) {
		this.Direccion = newDireccion;
	}

}
