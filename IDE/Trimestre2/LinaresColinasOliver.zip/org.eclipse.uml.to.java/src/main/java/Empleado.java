/*******************************************************************************
 * 2020, All rights reserved.
 *******************************************************************************/

// Start of user code (user defined imports)

// End of user code

/**
 * Description of Empleado.
 * 
 * @author mañana
 */
public class Empleado extends Persona {
	/**
	 * Description of the property COD_Empleado.
	 */
	private int COD_Empleado = 0;

	/**
	 * Description of the property Salario.
	 */
	private float Salario = 0F;

	/**
	 * Description of the property Funcion.
	 */
	private String Funcion = "";

	// Start of user code (user defined attributes for Empleado)

	// End of user code

	/**
	 * The constructor.
	 */
	public Empleado() {
		// Start of user code constructor for Empleado)
		super();
		// End of user code
	}

	/**
	 * Description of the method getCOD_Empleado.
	 * @return 
	 */
	public int getCOD_Empleado() {
		// Start of user code for method getCOD_Empleado
		int getCOD_Empleado = 0;
		return getCOD_Empleado;
		// End of user code
	}

	/**
	 * Description of the method getSalario.
	 * @return 
	 */
	public float getSalario() {
		// Start of user code for method getSalario
		float getSalario = 0F;
		return getSalario;
		// End of user code
	}

	/**
	 * Description of the method getFuncion.
	 * @return 
	 */
	public String getFuncion() {
		// Start of user code for method getFuncion
		String getFuncion = "";
		return getFuncion;
		// End of user code
	}

	/**
	 * Description of the method setCOD_Empleado.
	 * @param COD_Empleado 
	 */
	public void setCOD_Empleado(int COD_Empleado) {
		// Start of user code for method setCOD_Empleado
		// End of user code
	}

	/**
	 * Description of the method setSalario.
	 * @param Salario 
	 */
	public void setSalario(float Salario) {
		// Start of user code for method setSalario
		// End of user code
	}

	/**
	 * Description of the method setFuncion.
	 * @param Funcion 
	 */
	public void setFuncion(String Funcion) {
		// Start of user code for method setFuncion
		// End of user code
	}

	// Start of user code (user defined methods for Empleado)

	// End of user code
	/**
	 * Returns COD_Empleado.
	 * @return COD_Empleado 
	 */
	public int getCOD_Empleado() {
		return this.COD_Empleado;
	}

	/**
	 * Sets a value to attribute COD_Empleado. 
	 * @param newCOD_Empleado 
	 */
	public void setCOD_Empleado(int newCOD_Empleado) {
		this.COD_Empleado = newCOD_Empleado;
	}

	/**
	 * Returns Salario.
	 * @return Salario 
	 */
	public float getSalario() {
		return this.Salario;
	}

	/**
	 * Sets a value to attribute Salario. 
	 * @param newSalario 
	 */
	public void setSalario(float newSalario) {
		this.Salario = newSalario;
	}

	/**
	 * Returns Funcion.
	 * @return Funcion 
	 */
	public String getFuncion() {
		return this.Funcion;
	}

	/**
	 * Sets a value to attribute Funcion. 
	 * @param newFuncion 
	 */
	public void setFuncion(String newFuncion) {
		this.Funcion = newFuncion;
	}

}
