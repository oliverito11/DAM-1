/*******************************************************************************
 * 2020, All rights reserved.
 *******************************************************************************/

// Start of user code (user defined imports)

// End of user code

/**
 * Description of Cliente.
 * 
 * @author mañana
 */
public class Cliente extends Persona {
	/**
	 * Description of the property COD_Cliente.
	 */
	private int COD_Cliente = 0;

	/**
	 * Description of the property Empresa.
	 */
	private String Empresa = "";

	/**
	 * Description of the property Cargo.
	 */
	private String Cargo = "";

	// Start of user code (user defined attributes for Cliente)

	// End of user code

	/**
	 * The constructor.
	 */
	public Cliente() {
		// Start of user code constructor for Cliente)
		super();
		// End of user code
	}

	/**
	 * Description of the method getCOD_Cliente.
	 * @return 
	 */
	public int getCOD_Cliente() {
		// Start of user code for method getCOD_Cliente
		int getCOD_Cliente = 0;
		return getCOD_Cliente;
		// End of user code
	}

	/**
	 * Description of the method getEmpresa.
	 * @return 
	 */
	public String getEmpresa() {
		// Start of user code for method getEmpresa
		String getEmpresa = "";
		return getEmpresa;
		// End of user code
	}

	/**
	 * Description of the method getCargo.
	 * @return 
	 */
	public String getCargo() {
		// Start of user code for method getCargo
		String getCargo = "";
		return getCargo;
		// End of user code
	}

	/**
	 * Description of the method setCOD_Cliente.
	 * @param COD_Cliente 
	 */
	public void setCOD_Cliente(int COD_Cliente) {
		// Start of user code for method setCOD_Cliente
		// End of user code
	}

	/**
	 * Description of the method setEmpresa.
	 * @param Empresa 
	 */
	public void setEmpresa(String Empresa) {
		// Start of user code for method setEmpresa
		// End of user code
	}

	/**
	 * Description of the method setCargo.
	 * @param Cargo 
	 */
	public void setCargo(String Cargo) {
		// Start of user code for method setCargo
		// End of user code
	}

	// Start of user code (user defined methods for Cliente)

	// End of user code
	/**
	 * Returns COD_Cliente.
	 * @return COD_Cliente 
	 */
	public int getCOD_Cliente() {
		return this.COD_Cliente;
	}

	/**
	 * Sets a value to attribute COD_Cliente. 
	 * @param newCOD_Cliente 
	 */
	public void setCOD_Cliente(int newCOD_Cliente) {
		this.COD_Cliente = newCOD_Cliente;
	}

	/**
	 * Returns Empresa.
	 * @return Empresa 
	 */
	public String getEmpresa() {
		return this.Empresa;
	}

	/**
	 * Sets a value to attribute Empresa. 
	 * @param newEmpresa 
	 */
	public void setEmpresa(String newEmpresa) {
		this.Empresa = newEmpresa;
	}

	/**
	 * Returns Cargo.
	 * @return Cargo 
	 */
	public String getCargo() {
		return this.Cargo;
	}

	/**
	 * Sets a value to attribute Cargo. 
	 * @param newCargo 
	 */
	public void setCargo(String newCargo) {
		this.Cargo = newCargo;
	}

}
