#!/bin/bash
if [ ! -f $1 ]
then
	echo No existe el fichero
else
	echo El fichero sí existe
fi
