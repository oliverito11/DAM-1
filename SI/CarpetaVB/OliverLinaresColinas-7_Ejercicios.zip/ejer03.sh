#!/bin/bash
if [ ! -d $1 ]
then
	echo No existe el directorio
else
	echo Sí existe el directorio
fi
