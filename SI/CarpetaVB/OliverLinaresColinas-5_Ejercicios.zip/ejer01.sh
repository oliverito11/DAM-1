#!/bin/bash
clear
echo "		    MENU	        "
echo "============================================"
echo "[1]- Ver el nombre del usuario activo."
echo "[2]- Ver el nombre del directorio activo."
echo "[3]- Ver los ficheros del directorio activo."
echo "[4]- Comprobar existencia de un directorio"
echo "[5]- Salir."
echo "============================================"
echo "Elige una opción:"
read opc
case $opc in
	1)
		whoami
		;;
	2)
		pwd
		;;
	3)
		ls -la
		;;
	4)
		echo "Dame una ruta de un directorio:"
		read dir
		if [ ! -e $dir ]; then
			echo "El directorio $dir no existe."
		else
			echo "El directorio $dir sí existe."
		fi
		;;
	5)
		clear
		exit
		;;
	*)
		echo "Opción incorrecta..."
		sleep 1
		;;
esac
echo "Pulse una tecla para continuar..."
read
./ejer01.sh
