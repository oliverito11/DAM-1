#!/bin/bash
#Diario personal. Se creará un diario en la carpeta del usuario donde podrá añadir en él lo que quiera. Además, quedará identificado con una fecha y hora cada nueva entrada.
cd /home/$(whoami)/

#Si no existe el diario, se crea uno nuevo
if [ ! -f Diario.txt ]
then
	touch Diario.txt
	chmod +x Diario.txt
fi

echo $(date) \n\r >> Diario.txt
echo "Escribe:"
read desc
echo $desc >> Diario.txt
