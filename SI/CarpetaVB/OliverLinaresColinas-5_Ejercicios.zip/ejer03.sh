#!/bin/bash
cd /home/$(whoami)/
for fichero in $(ls . | grep .doc);
do
	chmod +r ./$fichero
done
