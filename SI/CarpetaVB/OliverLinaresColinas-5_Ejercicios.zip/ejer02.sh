#!/bin/bash
dirActual=$(pwd)
i=0

#Mostrar el directorio actual
echo $dirActual
sleep 1

#Mostrar la lista
cd
for fichero in $(ls)
do
	echo $i $fichero
	echo $i $fichero >> lista.txt
	let i++
done
