#!/bin/bash
clear
dir=$1
dir2=/home/$(whoami)/copia-$(date +%B-%d-%y)/

if [ -e $dir2 ]
then
	rm -r $dir2
fi
mkdir $dir2
cp -r $dir $dir2

cd
find $(pwd) -name *.xls -type f -exec cp -r {} "$dir2" \;
find $(pwd) -name *.doc? -type f -exec cp -r {} "$dir2" \;
