param($fichero)
if(Test-Path $fichero){
    Write-Host "El archivo existe"
}else{
    Write-Host "El archivo NO existe"
}