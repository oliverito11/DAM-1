param($fichero)
if(Test-Path $fichero){
    Write-Host "El directorio existe"
}else{
    Write-Host "El directorio NO existe"
}